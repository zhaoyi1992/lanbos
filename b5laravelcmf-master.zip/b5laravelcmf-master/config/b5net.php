<?php
// +----------------------------------------------------------------------
// | B5LaravelCMF [快捷通用基础开发管理平台]
// +----------------------------------------------------------------------
// | Author: 冰舞 <357145480@qq.com>
// +----------------------------------------------------------------------
return [
    //文件服务器地址
    'fileDomain' => '',

    //默认超管id
    'root_admin_id' => 10000,

    //默认组织根id
    'root_struct_id' => 100,

    //默认超管角色
    'root_role_id' => 1,

    //后台登陆session键
    'admin_login_session' => 'b5laravel9cmf_admin',

    'admin_login_cookie' => 'b5laravel9cmf_admin_cookie'
];
