@section('css_common')
    <link rel="stylesheet" href="{{asset('static/plugins/ztree/css/metroStyle/metroStyle.css')}}">
@append
@section('js_common')
    <script src="{{asset('static/plugins/ztree/js/jquery.ztree.all.min.js')}}"></script>
    <script src="{{asset('static/plugins/ztree/js/jquery.ztree.exhide.min.js')}}"></script>
@append
