@section('js_common')
    <script src="{{asset('static/admin/js/uploader.js')}}"></script>
@append
