@section('js_common')
    <script src="{{asset('static/plugins/jscolor.min.js')}}"></script>
@append
