@section('css_common')
    <link rel="stylesheet" href="{{asset('static/plugins/dragula/dragula.min.css')}}">
@append
@section('js_common')
    <script src="{{asset('static/plugins/dragula/dragula.min.js')}}"></script>
@append
