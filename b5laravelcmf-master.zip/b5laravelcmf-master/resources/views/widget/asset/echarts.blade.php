@section('js_common')
    <script src="{{asset('static/plugins/echarts.min.js')}}"></script>
@append
