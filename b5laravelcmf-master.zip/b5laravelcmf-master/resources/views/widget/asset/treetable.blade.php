@section('js_common')
    <script src="{{asset('static/plugins/bootstrap-treetable/bootstrap-treetable.js')}}"></script>
@append
