@section('css_common')
    <link rel="stylesheet" href="{{asset('static/plugins/viewerjs/viewer.min.css')}}">
@append
@section('js_common')
    <script src="{{asset('static/plugins/viewerjs/viewer.min.js')}}"></script>
@append
