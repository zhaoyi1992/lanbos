@section('css_common')
    <link rel="stylesheet" href="{{asset('static/plugins/cropper/cropper.min.css')}}">
@append
@section('js_common')
    <script src="{{asset('static/plugins/cropper/cropper.min.js')}}"></script>
    <script src="{{asset('static/plugins/cropper/jquery-cropper.min.js')}}"></script>
@append
