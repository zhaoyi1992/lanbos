@section('css_common')
    <link rel="stylesheet" href="{{asset('static/plugins/jquery-layout/layout-default.css')}}">
@append
@section('js_common')
    <script src="{{asset('static/plugins/jquery-layout/jquery.layout.min.js')}}"></script>
@append
