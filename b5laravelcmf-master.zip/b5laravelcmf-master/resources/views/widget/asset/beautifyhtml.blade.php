@section('js_common')
    <script src="{{asset('static/plugins/beautifyhtml/beautifyhtml.js')}}"></script>
@append
