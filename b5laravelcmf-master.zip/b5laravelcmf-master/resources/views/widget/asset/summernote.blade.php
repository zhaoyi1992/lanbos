@section('css_common')
    <link rel="stylesheet" href="{{asset('static/plugins/summernote/summernote.min.css')}}">
@append
@section('js_common')
    <script src="{{asset('static/plugins/summernote/summernote.min.js')}}"></script>
    <script src="{{asset('static/plugins/summernote/lang/summernote-zh-CN.min.js')}}"></script>
@append
