@section('js_common')
    <script src="{{asset('static/plugins/jquery-ui-1.10.4.min.js')}}"></script>
@append
