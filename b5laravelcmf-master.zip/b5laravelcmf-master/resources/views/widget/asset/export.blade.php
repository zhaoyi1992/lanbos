@section('js_common')
    <script src="{{asset('static/plugins/bootstrap-table/extensions/export/tableExport.js')}}"></script>
    <script src="{{asset('static/plugins/bootstrap-table/extensions/export/bootstrap-table-export.js')}}"></script>
@append
