@section('js_common')
    <script src="{{asset('static/plugins/My97DatePicker/WdatePicker.js')}}"></script>
@append
