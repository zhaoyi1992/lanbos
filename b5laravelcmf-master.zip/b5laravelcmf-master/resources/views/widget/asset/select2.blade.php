@section('css_common')
    <link rel="stylesheet" href="{{asset('static/plugins/select2/select2.min.css')}}">
    <link rel="stylesheet" href="{{asset('static/plugins/select2/select2-bootstrap.css')}}">
@append
@section('js_common')
    <script src="{{asset('static/plugins/select2/select2.min.js')}}"></script>
@append
