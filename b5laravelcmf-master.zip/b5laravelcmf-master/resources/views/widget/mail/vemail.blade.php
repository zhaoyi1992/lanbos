<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>邮箱验证</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
</head>
<body>
<div class="verify-email">
    <p>你好 <?=$name?> ：</p>

    <p>请点击下面链接验证激活您的邮箱账号:</p>

    <p><a href="<?=$url?>"><?=$url?></a></p>
</div>
</body>
</html>
