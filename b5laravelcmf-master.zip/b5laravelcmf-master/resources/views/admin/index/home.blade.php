@extends('admin.layout.layout')
@section('title', '主页')

@section('content')
    xxxxx
@endsection

