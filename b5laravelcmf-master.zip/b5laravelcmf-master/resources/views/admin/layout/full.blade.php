<!DOCTYPE html>
<html>
@include('admin.layout.header')
<body class="gray-bg">
    @yield('content')
    @include('admin.layout.footer')
</body>
</html>
